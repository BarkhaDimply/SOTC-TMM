import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { AuthService } from 'src/app/services/auth/auth.service';
import { GlobalService } from 'src/app/services/global/global.service';
import {  Location } from '@angular/common';
import {Platform,AlertController,IonRouterOutlet} from '@ionic/angular';

import { ApiService } from 'src/app/services/api/api.service';
@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})

export class TabsPage implements OnInit{
  isModal = false;
  routVal='';
  transactionValue:any = [];
  btnSubstatus= true;
  constructor(private globalService: GlobalService,private auth: AuthService, private router: Router,private location: Location,
              private platform : Platform,
              private alertController:AlertController, private apiServices:ApiService,  private actRoute: ActivatedRoute, ) { }

  ngOnInit(): void {
    this.getDataByTabs();
    this.auth.getUserStatus.subscribe(val => {
      if (val === '0') {
        this.router.navigate(['/login']);
      }
    });

    this.actRoute.queryParams.subscribe(params => {
      this.getDataByTabs();
    });


  }
  getDataByTabs(){
    this.apiServices.getAllTransctionHistoryByTime().subscribe((result:any) => {

      Object.entries(result.data).forEach(
        ([key, value]) => {

          this.transactionValue.push({transKey:key,transValue:value});
           console.log("Trand11",this.transactionValue);


        });
      // plus button hide function

      this.transactionValue.forEach(itms => {
        itms.transValue.forEach(itm=>{


          if((itm.submission_status == 1 || itm.submission_status == 3) && itm.show_transaction == 0 && itm.category != 'BALANCE ADDED' && itm.category != 'misc_collection' && itm.category != 'tm_transfer' ){
            this.btnSubstatus =false;


          }
        });


      });});
  }
  async setOpen() {
    this.getDataByTabs();
    console.log("hlo moto");
    if(this.btnSubstatus){

      console.log("sss",this.btnSubstatus);
      this.router.navigate(['/tabs/my-expenses/transaction-modal']);
    }
    if(!this.btnSubstatus){
      console.log("mmm",this.btnSubstatus);
      const alert = await this.alertController.create({
        cssClass: '',
        message: 'Transaction Already Submitted',
        mode: 'ios',
        buttons: ['OK']

      });

      await alert.present();}
    };





  // ButtonEvent(){
  //   this.platform.backButton.subscribeWithPriority(5,()=> {
  //
  //       this.isModal = false;
  //       console.log(this.isModal);
  //   }
  //
  //    );
  }

