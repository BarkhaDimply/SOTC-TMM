import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecordTransactionPageRoutingModule } from './record-transaction-routing.module';

import { RecordTransactionPage } from './record-transaction.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RecordTransactionPageRoutingModule
  
  ],
  declarations: [RecordTransactionPage]
})
export class RecordTransactionPageModule {}
