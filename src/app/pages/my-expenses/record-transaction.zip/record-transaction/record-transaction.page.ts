import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { ApiService } from 'src/app/services/api/api.service';
import { GlobalService } from 'src/app/services/global/global.service';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
@Component({
  selector: 'app-record-transaction',
  templateUrl: './record-transaction.page.html',
  styleUrls: ['./record-transaction.page.scss'],
})
export class RecordTransactionPage implements OnInit {
  amtPaid:string="";
  selectedCurrency:string="";
  handoverType:string=""
  getAllCatergories:any;
 subCategory:any;
 selected_category_id:number;
  selected_subcategory_id:any="";
  expenseData:any;
  showCurrency:any= [];
  selectedDate:string="";
  description:string="";
  imageDisplay: string="";
  imgPath: string="";
  constructor(private apiService: ApiService,
              private alertCtrl:AlertController,
              private globalService: GlobalService) {

 this.expenseData = JSON.parse(localStorage.getItem("expensesData"));
  }

  ngOnInit() {
    this.globalService.presentLoading();
    this.apiService.getCategoriesFromServer().subscribe((result:any) => {
      this.getAllCatergories = result.categories;
      this.globalService.dismissLoading();


    });
    if(this.expenseData){
      this.expenseData.forEach(element => {

          this.showCurrency.push(element.currency_name);

      });
    }

  }

  getSubcatgeory(ev:any):void{
      console.log("EV::",ev);
      this.selected_category_id = parseInt(ev.target.value);
      this.subCategory = "";
      this.getAllCatergories.forEach(element => {
        if(this.selected_category_id == element.id){
          if(element.sub_category.length > 0){
          this.subCategory = element.sub_category;
          }
        }
      });


  }

  getSubcatgeoryId(ev:any) :void {
    this.selected_subcategory_id = ev.target.value;
  }

    selectedHandoverType(type:any):void
  {
  this.handoverType = type
  }

  selectCurrencyDropdown(name:any):void
  {
    this.selectedCurrency = name
  }

  postRegularPayment() {
    if(this.amtPaid == "") {
      alert('Please enter Amount')
      return;
    }
    this.globalService.presentLoading();
    var Users:string = localStorage.getItem("user")
    if(this.selectedCurrency == ""){
      this.selectedCurrency =  this.showCurrency[0]
    }
    if(this.handoverType == ""){
      this.handoverType =  'Cash'
    }

    let params:any = {}
    params.group_id = JSON.parse(Users).order_id;
    params.driver_id = localStorage.getItem("manager_id");
    params.transaction_amount = this.amtPaid;

    params.currency = this.selectedCurrency;
    params.date_of_transaction = this.selectedDate;
    params.transaction_from = this.handoverType;
    params.driver_name = localStorage.getItem("manager_name");
    params.token = "";
    params.mode = "create";
    params.transaction_type = "Debit";
    params.discription = this.description;
    params.category_id = this.selected_category_id;
    params.sub_category = this.selected_subcategory_id;
    params.image = this.imgPath;

    this.apiService.postCurrencyExchange(params).subscribe((result:any) =>{
      this.globalService.dismissLoading();
      if(result.status == "false"){
        alert(result.message);
      }
       if(result.message == "success") {
        alert('transaction successful');
        window.history.back();
      }
    })
  }
  async  openGallery(){
    const image = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.Uri,
      source: CameraSource.Photos // Camera, Photos or Prompt!
  });

  if (image) {
    this.imageDisplay = image.webPath;
    this.imgPath = image.path;

  }
   }

}
